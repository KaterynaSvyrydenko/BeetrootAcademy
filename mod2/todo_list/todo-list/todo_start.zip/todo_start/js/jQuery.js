    const INCOMPLETE_LIST = $('#incomplete-tasks');
    const COMPLETE_LIST = $('#completed-tasks');
    const NEW_TASK_INPUT = $('#new-task');
    const TEMPLATE_LI = $('#templateLi');
    const CONTAINER = $('.container');

    const CLASS_EDIT = $('editMode');
    const CLASS_BTN_EDIT = $('edit');
    const CLASS_BTN_DELETE = $('delete');


// CONTAINER.addEventListener('click', onClick);
// CONTAINER.addEventListener('keypress', onKeyPress);


$(function() {
    $('#add').click(function(evt){
        var newLi = $('li.template');
        var cloneLi = newLi.clone();
        var text = $('#new-task').val();
        cloneLi.text(text);
        cloneLi.toogleClass('.template');
        $('#incomplete-tasks').append(cloneLi);
    })
/*    $('#add').click(function(){
        var text = $('#new-task').val();
        cloneLi.text(text);
    })*/
})
// $(function(){

//     $("#tabs a").click(function(evt){
//        var target = evt.target,
//            targetPanel = target.attr("href");
//        $(".panel").hide();
//        $("#tabs a.active").removeClass("active");
//        target.addClass("active").blur();
//        $(targetPanel).fadeIn(300);
//        evt.preventDefault();
//     });

//     $("#tabs a:first").click();
// })


$(function (){ 
    $('button').click(function(){
       var text = $('input').val(); 
       $('div').text(text);
    });
});

// клонирование єлемента var newElems = $('div.dcell').clone();